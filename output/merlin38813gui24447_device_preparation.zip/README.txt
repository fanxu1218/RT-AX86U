GUI24447 本地设备准备文档（2026-11-10）

先阅读 merlin38813gui24447_device_guide.md，再将 merlin38813gui24447_device_acceptance.md 复制到项目之外的私有目录填写。
当前仅有方案，NOT_FLASH_READY / 未实机验收，50 项设备检查全部未验证。

本 ZIP 不包含固件、恢复工具、设备配置或账号数据。先核对当前实际来源，分别准备对应原包和备份；不能把回 P7 等同恢复到升级前版本。

macOS/Linux：解压后在本目录执行 shasum -a 256 -c GUI24447-GUIDE-SHA256SUMS（Linux 也可用 sha256sum -c）。
Windows：用 PowerShell Get-FileHash -Algorithm SHA256 分别计算三个文档文件，与同目录清单逐项比较。
固件和插件的文件名/大小/哈希及下载来源见指南第 2 节；本清单只校验文档。

指南与模板的相对链接可离线互跳；ASUS/Merlin 原始说明、发布和冻结报告链接需要网络。
所有设备命令仅为未来维护窗口示例，本轮没有连接设备、停止服务、备份、刷写、安装或回退。
